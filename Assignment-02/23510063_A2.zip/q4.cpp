#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl '\n'

signed main()
{
    int s, t;
    cin >> s >> t;
    int cnt = 0;
    int mini = min(s, t)+1;
    cout << "Number of co-ordinates: " << mini * (mini + 1) / 2 << endl;
    return 0;
}